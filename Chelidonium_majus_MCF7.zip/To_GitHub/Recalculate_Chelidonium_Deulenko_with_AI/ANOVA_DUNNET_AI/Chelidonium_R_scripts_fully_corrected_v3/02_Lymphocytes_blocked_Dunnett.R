# ================================================================
# Corrected analysis of blank-corrected MTT OD values
# Four independent experiments; repeated doses within experiment
# Multiplicity method: Dunnett only
# ================================================================

if (!requireNamespace("multcomp", quietly = TRUE)) {
  stop("Install package 'multcomp' before running this script.")
}

library(multcomp)

# ================================================================
# Shared output utilities
# ================================================================

get_output_dir <- function() {
  # Reuse an output directory supplied by 04_run_all.R when available.
  if (exists("analysis_output_dir", envir = .GlobalEnv, inherits = FALSE)) {
    out <- get("analysis_output_dir", envir = .GlobalEnv)
    dir.create(out, recursive = TRUE, showWarnings = FALSE)
    return(normalizePath(out, winslash = "/", mustWork = FALSE))
  }

  candidates <- c(
    file.path(getwd(), "results"),
    file.path(path.expand("~"), "Chelidonium_R_results"),
    file.path(tempdir(), "Chelidonium_R_results")
  )

  for (candidate in candidates) {
    ok <- tryCatch({
      dir.create(candidate, recursive = TRUE, showWarnings = FALSE)
      test_file <- file.path(candidate, paste0("write_test_", Sys.getpid(), ".tmp"))
      created <- file.create(test_file)
      if (isTRUE(created)) unlink(test_file)
      isTRUE(created)
    }, error = function(e) FALSE)

    if (ok) {
      return(normalizePath(candidate, winslash = "/", mustWork = FALSE))
    }
  }

  stop("No writable output directory could be created.")
}

safe_write_csv <- function(x, filename, row.names = FALSE) {
  path <- file.path(output_dir, filename)
  tryCatch(
    {
      utils::write.csv(x, path, row.names = row.names)
      message("Saved: ", path)
      TRUE
    },
    error = function(e) {
      warning("Could not save ", filename, ": ", conditionMessage(e))
      FALSE
    }
  )
}

safe_capture_output <- function(..., filename) {
  path <- file.path(output_dir, filename)
  expressions <- substitute(list(...))[-1L]

  tryCatch(
    {
      con <- file(path, open = "wt", encoding = "UTF-8")
      on.exit(close(con), add = TRUE)

      for (expr in expressions) {
        value <- eval(expr, envir = parent.frame())
        if (!is.null(value)) {
          capture.output(print(value), file = con)
        }
      }

      message("Saved: ", path)
      TRUE
    },
    error = function(e) {
      warning("Could not save ", filename, ": ", conditionMessage(e))
      FALSE
    }
  )
}

safe_save_diagnostics <- function(model, filename) {
  png_path <- file.path(output_dir, filename)

  png_ok <- tryCatch(
    {
      grDevices::png(
        filename = png_path,
        width = 1800,
        height = 1800,
        res = 220
      )
      graphics::par(mfrow = c(2, 2))
      graphics::plot(model)
      grDevices::dev.off()
      message("Saved: ", png_path)
      TRUE
    },
    error = function(e) {
      if (grDevices::dev.cur() > 1L) {
        try(grDevices::dev.off(), silent = TRUE)
      }
      FALSE
    }
  )

  if (png_ok) return(TRUE)

  # Portable fallback when the Windows PNG device is unavailable.
  pdf_path <- sub("\\.png$", ".pdf", png_path, ignore.case = TRUE)

  pdf_ok <- tryCatch(
    {
      grDevices::pdf(pdf_path, width = 8, height = 8)
      graphics::par(mfrow = c(2, 2))
      graphics::plot(model)
      grDevices::dev.off()
      message("PNG unavailable; diagnostics saved as PDF: ", pdf_path)
      TRUE
    },
    error = function(e) {
      if (grDevices::dev.cur() > 1L) {
        try(grDevices::dev.off(), silent = TRUE)
      }
      warning(
        "Diagnostic plot could not be saved, but the statistical analysis is complete. ",
        conditionMessage(e)
      )
      FALSE
    }
  )

  pdf_ok
}

output_dir <- get_output_dir()
cat("Output directory: ", output_dir, "\n", sep = "")

lymph_wide <- data.frame(
  experiment = factor(1:4),
  check.names = FALSE,
  "3"          = c(0.136, 0.125, 0.170, 0.156),
  "1.5"        = c(0.388, 0.385, 0.375, 0.341),
  "0.75"       = c(0.388, 0.441, 0.415, 0.397),
  "0.375"      = c(0.423, 0.488, 0.4337, 0.398),
  "0.1875"     = c(0.499, 0.482, 0.470, 0.387),
  "0.09375"    = c(0.397, 0.429, 0.386, 0.411),
  "0.046875"   = c(0.403, 0.401, 0.408, 0.4712),
  "0.0234375"  = c(0.449, 0.454, 0.414, 0.489),
  "0.01171875" = c(0.431, 0.496, 0.437, 0.456),
  "0"          = c(0.429, 0.453, 0.479, 0.3987)
)

dose_names <- setdiff(names(lymph_wide), "experiment")

lymph <- reshape(
  lymph_wide,
  varying = dose_names,
  v.names = "OD",
  timevar = "dose",
  times = dose_names,
  direction = "long"
)
rownames(lymph) <- NULL

lymph$experiment <- factor(lymph$experiment)
lymph$dose <- factor(lymph$dose, levels = c("0", setdiff(dose_names, "0")))

stopifnot(
  nlevels(lymph$experiment) == 4L,
  all(table(lymph$experiment) == length(dose_names)),
  !anyNA(lymph$OD),
  all(lymph$OD > 0)
)

controls <- lymph[lymph$dose == "0", c("experiment", "OD")]
names(controls)[2] <- "control_OD"
lymph <- merge(lymph, controls, by = "experiment", sort = FALSE)
lymph$viability_percent <- 100 * lymph$OD / lymph$control_OD
lymph$log_response_ratio <- log(lymph$OD / lymph$control_OD)

fit_lymph <- lm(OD ~ experiment + dose, data = lymph)
anova_lymph <- anova(fit_lymph)

dunnett_lymph <- glht(fit_lymph, linfct = mcp(dose = "Dunnett"))
dunnett_summary_lymph <- summary(dunnett_lymph)
dunnett_ci_lymph <- confint(dunnett_lymph)
shapiro_lymph <- shapiro.test(residuals(fit_lymph))

cat("\n================ LYMPHOCYTE BLOCKED ANOVA ================\n")
print(anova_lymph)
cat("\n================ LYMPHOCYTE DUNNETT TESTS ================\n")
print(dunnett_summary_lymph)
cat("\n========== LYMPHOCYTE SIMULTANEOUS 95% CONFIDENCE INTERVALS ==========\n")
print(dunnett_ci_lymph)
cat("\n================ LYMPHOCYTE RESIDUAL NORMALITY ================\n")
print(shapiro_lymph)

summary_fun <- function(x) {
  c(
    mean = mean(x),
    SD = sd(x),
    median = median(x),
    min = min(x),
    max = max(x),
    n = length(x)
  )
}

lymph_summary <- aggregate(
  cbind(OD, viability_percent) ~ dose,
  data = lymph,
  FUN = summary_fun
)

safe_write_csv(lymph, "Lymphocyte_long_data_blank_corrected.csv")
safe_write_csv(lymph_summary, "Lymphocyte_descriptive_summary.csv")

results_path <- file.path(output_dir, "Lymphocyte_corrected_results.txt")
tryCatch(
  {
    sink(results_path)
    cat("Lymphocyte blocked model: OD ~ experiment + dose\n\n")
    print(anova_lymph)
    cat("\nDunnett contrasts\n")
    print(dunnett_summary_lymph)
    cat("\nSimultaneous 95% confidence intervals\n")
    print(dunnett_ci_lymph)
    cat("\nShapiro-Wilk test of residuals\n")
    print(shapiro_lymph)
    sink()
    message("Saved: ", results_path)
  },
  error = function(e) {
    if (sink.number() > 0L) sink()
    warning("Could not save lymphocyte text output: ", conditionMessage(e))
  }
)

safe_save_diagnostics(fit_lymph, "Lymphocyte_model_diagnostics.png")
