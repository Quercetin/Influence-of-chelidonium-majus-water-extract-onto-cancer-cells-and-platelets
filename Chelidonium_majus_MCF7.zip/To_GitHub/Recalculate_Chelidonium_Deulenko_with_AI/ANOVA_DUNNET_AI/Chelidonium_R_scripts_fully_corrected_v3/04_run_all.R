# ================================================================
# Run all analyses robustly on Windows
# ================================================================

scripts <- c(
  "01_MCF7_blocked_Dunnett.R",
  "02_Lymphocytes_blocked_Dunnett.R",
  "03_Combined_response_profile_analysis.R"
)

missing_scripts <- scripts[!file.exists(scripts)]
if (length(missing_scripts) > 0L) {
  stop(
    "Missing scripts: ",
    paste(missing_scripts, collapse = ", "),
    "\nCurrent directory: ",
    getwd()
  )
}

# Prefer the user's home directory rather than Documents, which may be
# protected by Windows Controlled Folder Access.
candidate_dirs <- c(
  file.path(path.expand("~"), "Chelidonium_R_results"),
  file.path(tempdir(), "Chelidonium_R_results")
)

analysis_output_dir <- NULL

for (candidate in candidate_dirs) {
  ok <- tryCatch({
    dir.create(candidate, recursive = TRUE, showWarnings = FALSE)
    test_file <- file.path(candidate, paste0("write_test_", Sys.getpid(), ".tmp"))
    created <- file.create(test_file)
    if (isTRUE(created)) unlink(test_file)
    isTRUE(created)
  }, error = function(e) FALSE)

  if (ok) {
    analysis_output_dir <- normalizePath(
      candidate,
      winslash = "/",
      mustWork = FALSE
    )
    break
  }
}

if (is.null(analysis_output_dir)) {
  stop("Could not create a writable output directory.")
}

assign("analysis_output_dir", analysis_output_dir, envir = .GlobalEnv)

cat("Script directory: ", normalizePath(getwd(), winslash = "/", mustWork = FALSE), "\n", sep = "")
cat("Output directory: ", analysis_output_dir, "\n", sep = "")

status <- setNames(rep("not started", length(scripts)), scripts)

for (script in scripts) {
  cat("\n\nRUNNING: ", script, "\n", sep = "")

  result <- tryCatch(
    {
      source(script, echo = FALSE, local = globalenv())
      list(ok = TRUE, message = "completed")
    },
    error = function(e) {
      message("ERROR IN ", script, ": ", conditionMessage(e))
      list(ok = FALSE, message = paste0("failed: ", conditionMessage(e)))
    }
  )

  status[[script]] <- result$message
}

cat("\n\n================ FINAL RUN STATUS ================\n")
print(status)

if (isTRUE(all(status == "completed"))) {
  cat("\nAll corrected analyses completed successfully.\n")
  cat("Results were saved in:\n", analysis_output_dir, "\n", sep = "")
} else {
  cat("\nAt least one script did not complete. Review the status above.\n")
  cat("Any completed outputs are in:\n", analysis_output_dir, "\n", sep = "")
}
