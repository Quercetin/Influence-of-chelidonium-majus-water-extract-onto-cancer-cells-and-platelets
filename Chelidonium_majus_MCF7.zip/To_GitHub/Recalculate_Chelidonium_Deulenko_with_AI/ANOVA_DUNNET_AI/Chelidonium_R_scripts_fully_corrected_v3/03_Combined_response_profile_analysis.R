# ================================================================
# Corrected comparison of MCF-7 and lymphocyte response profiles
#
# The two cell-series are unpaired.
# Cross-cell analysis uses within-experiment log response ratios.
# No dose-specific cell-type post-hoc tests are performed.
# Dunnett results are produced only in scripts 01 and 02.
# ================================================================

# ================================================================
# Shared output utilities
# ================================================================

get_output_dir <- function() {
  # Reuse an output directory supplied by 04_run_all.R when available.
  if (exists("analysis_output_dir", envir = .GlobalEnv, inherits = FALSE)) {
    out <- get("analysis_output_dir", envir = .GlobalEnv)
    dir.create(out, recursive = TRUE, showWarnings = FALSE)
    return(normalizePath(out, winslash = "/", mustWork = FALSE))
  }

  candidates <- c(
    file.path(getwd(), "results"),
    file.path(path.expand("~"), "Chelidonium_R_results"),
    file.path(tempdir(), "Chelidonium_R_results")
  )

  for (candidate in candidates) {
    ok <- tryCatch({
      dir.create(candidate, recursive = TRUE, showWarnings = FALSE)
      test_file <- file.path(candidate, paste0("write_test_", Sys.getpid(), ".tmp"))
      created <- file.create(test_file)
      if (isTRUE(created)) unlink(test_file)
      isTRUE(created)
    }, error = function(e) FALSE)

    if (ok) {
      return(normalizePath(candidate, winslash = "/", mustWork = FALSE))
    }
  }

  stop("No writable output directory could be created.")
}

safe_write_csv <- function(x, filename, row.names = FALSE) {
  path <- file.path(output_dir, filename)
  tryCatch(
    {
      utils::write.csv(x, path, row.names = row.names)
      message("Saved: ", path)
      TRUE
    },
    error = function(e) {
      warning("Could not save ", filename, ": ", conditionMessage(e))
      FALSE
    }
  )
}

safe_capture_output <- function(..., filename) {
  path <- file.path(output_dir, filename)
  expressions <- substitute(list(...))[-1L]

  tryCatch(
    {
      con <- file(path, open = "wt", encoding = "UTF-8")
      on.exit(close(con), add = TRUE)

      for (expr in expressions) {
        value <- eval(expr, envir = parent.frame())
        if (!is.null(value)) {
          capture.output(print(value), file = con)
        }
      }

      message("Saved: ", path)
      TRUE
    },
    error = function(e) {
      warning("Could not save ", filename, ": ", conditionMessage(e))
      FALSE
    }
  )
}

safe_save_diagnostics <- function(model, filename) {
  png_path <- file.path(output_dir, filename)

  png_ok <- tryCatch(
    {
      grDevices::png(
        filename = png_path,
        width = 1800,
        height = 1800,
        res = 220
      )
      graphics::par(mfrow = c(2, 2))
      graphics::plot(model)
      grDevices::dev.off()
      message("Saved: ", png_path)
      TRUE
    },
    error = function(e) {
      if (grDevices::dev.cur() > 1L) {
        try(grDevices::dev.off(), silent = TRUE)
      }
      FALSE
    }
  )

  if (png_ok) return(TRUE)

  # Portable fallback when the Windows PNG device is unavailable.
  pdf_path <- sub("\\.png$", ".pdf", png_path, ignore.case = TRUE)

  pdf_ok <- tryCatch(
    {
      grDevices::pdf(pdf_path, width = 8, height = 8)
      graphics::par(mfrow = c(2, 2))
      graphics::plot(model)
      grDevices::dev.off()
      message("PNG unavailable; diagnostics saved as PDF: ", pdf_path)
      TRUE
    },
    error = function(e) {
      if (grDevices::dev.cur() > 1L) {
        try(grDevices::dev.off(), silent = TRUE)
      }
      warning(
        "Diagnostic plot could not be saved, but the statistical analysis is complete. ",
        conditionMessage(e)
      )
      FALSE
    }
  )

  pdf_ok
}

output_dir <- get_output_dir()
cat("Output directory: ", output_dir, "\n", sep = "")


mcf7_wide <- data.frame(
  experiment = factor(1:4),
  check.names = FALSE,
  "3"          = c(0.423, 0.501, 0.512, 0.363),
  "1.5"        = c(0.396, 0.525, 0.468, 0.416),
  "0.75"       = c(0.632, 1.085, 0.875, 0.407),
  "0.375"      = c(0.666, 0.604, 0.671, 0.428),
  "0.1875"     = c(0.762, 1.167, 0.755, 1.013),
  "0.09375"    = c(0.983, 1.021, 0.835, 0.790),
  "0.046875"   = c(1.196, 1.292, 1.206, 1.173),
  "0.0234375"  = c(1.170, 1.110, 0.679, 0.392),
  "0.01171875" = c(1.187, 1.111, 1.205, 0.730),
  "0"          = c(1.304, 0.871, 1.207, 0.798)
)

lymph_wide <- data.frame(
  experiment = factor(1:4),
  check.names = FALSE,
  "3"          = c(0.136, 0.125, 0.170, 0.156),
  "1.5"        = c(0.388, 0.385, 0.375, 0.341),
  "0.75"       = c(0.388, 0.441, 0.415, 0.397),
  "0.375"      = c(0.423, 0.488, 0.4337, 0.398),
  "0.1875"     = c(0.499, 0.482, 0.470, 0.387),
  "0.09375"    = c(0.397, 0.429, 0.386, 0.411),
  "0.046875"   = c(0.403, 0.401, 0.408, 0.4712),
  "0.0234375"  = c(0.449, 0.454, 0.414, 0.489),
  "0.01171875" = c(0.431, 0.496, 0.437, 0.456),
  "0"          = c(0.429, 0.453, 0.479, 0.3987)
)

common_doses <- intersect(
  setdiff(names(mcf7_wide), "experiment"),
  setdiff(names(lymph_wide), "experiment")
)

to_long <- function(wide, cell_name) {
  long <- reshape(
    wide,
    varying = common_doses,
    v.names = "OD",
    timevar = "dose",
    times = common_doses,
    direction = "long"
  )
  rownames(long) <- NULL
  long$cell <- cell_name
  long
}

dat <- rbind(
  to_long(mcf7_wide, "MCF7"),
  to_long(lymph_wide, "Lymphocytes")
)

dat$cell <- factor(dat$cell, levels = c("Lymphocytes", "MCF7"))
dat$experiment <- factor(dat$experiment)
dat$experiment_nested <- interaction(dat$cell, dat$experiment, drop = TRUE)
dat$dose <- factor(dat$dose, levels = c("0", setdiff(common_doses, "0")))

stopifnot(
  nlevels(dat$experiment_nested) == 8L,
  !anyNA(dat$OD),
  all(dat$OD > 0)
)

controls <- dat[dat$dose == "0", c("cell", "experiment", "OD")]
names(controls)[3] <- "control_OD"

dat <- merge(
  dat,
  controls,
  by = c("cell", "experiment"),
  sort = FALSE
)

dat$viability_percent <- 100 * dat$OD / dat$control_OD
dat$log_response_ratio <- log(dat$OD / dat$control_OD)

noncontrol <- droplevels(subset(dat, dose != "0"))

fit_full <- lm(
  log_response_ratio ~ experiment_nested + cell * dose,
  data = noncontrol
)

fit_reduced <- lm(
  log_response_ratio ~ experiment_nested + cell + dose,
  data = noncontrol
)

interaction_test <- anova(fit_reduced, fit_full)
shapiro_combined <- shapiro.test(residuals(fit_full))

cat("\n================ RESPONSE-PROFILE INTERACTION TEST ================\n")
print(interaction_test)
cat("\n================ COMBINED MODEL RESIDUAL NORMALITY ================\n")
print(shapiro_combined)

cat(
  "\nInterpretation: the model-comparison p-value tests whether the\n",
  "normalised dose-response profile differs between MCF-7 and lymphocytes.\n",
  "Dunnett contrasts are reported only in scripts 01 and 02.\n",
  sep = ""
)

safe_write_csv(dat, "Combined_long_normalized_data.csv")

results_path <- file.path(output_dir, "Combined_corrected_results.txt")
tryCatch(
  {
    sink(results_path)
    cat("Comparison of normalised MCF-7 and lymphocyte response profiles\n\n")
    print(interaction_test)
    cat("\nShapiro-Wilk test of full-model residuals\n")
    print(shapiro_combined)
    sink()
    message("Saved: ", results_path)
  },
  error = function(e) {
    if (sink.number() > 0L) sink()
    warning("Could not save combined text output: ", conditionMessage(e))
  }
)

safe_save_diagnostics(fit_full, "Combined_interaction_model_diagnostics.png")
