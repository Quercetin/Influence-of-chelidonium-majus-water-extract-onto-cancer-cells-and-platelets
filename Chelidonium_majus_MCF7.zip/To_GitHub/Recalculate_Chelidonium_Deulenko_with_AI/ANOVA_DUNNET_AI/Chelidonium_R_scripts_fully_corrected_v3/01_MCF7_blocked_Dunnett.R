# ================================================================
# Corrected analysis of blank-corrected MTT OD values
# Four independent experiments; repeated doses within experiment
# Multiplicity method: Dunnett only
# ================================================================

if (!requireNamespace("multcomp", quietly = TRUE)) {
  stop("Install package 'multcomp' before running this script.")
}

library(multcomp)

# ================================================================
# Shared output utilities
# ================================================================

get_output_dir <- function() {
  # Reuse an output directory supplied by 04_run_all.R when available.
  if (exists("analysis_output_dir", envir = .GlobalEnv, inherits = FALSE)) {
    out <- get("analysis_output_dir", envir = .GlobalEnv)
    dir.create(out, recursive = TRUE, showWarnings = FALSE)
    return(normalizePath(out, winslash = "/", mustWork = FALSE))
  }

  candidates <- c(
    file.path(getwd(), "results"),
    file.path(path.expand("~"), "Chelidonium_R_results"),
    file.path(tempdir(), "Chelidonium_R_results")
  )

  for (candidate in candidates) {
    ok <- tryCatch({
      dir.create(candidate, recursive = TRUE, showWarnings = FALSE)
      test_file <- file.path(candidate, paste0("write_test_", Sys.getpid(), ".tmp"))
      created <- file.create(test_file)
      if (isTRUE(created)) unlink(test_file)
      isTRUE(created)
    }, error = function(e) FALSE)

    if (ok) {
      return(normalizePath(candidate, winslash = "/", mustWork = FALSE))
    }
  }

  stop("No writable output directory could be created.")
}

safe_write_csv <- function(x, filename, row.names = FALSE) {
  path <- file.path(output_dir, filename)
  tryCatch(
    {
      utils::write.csv(x, path, row.names = row.names)
      message("Saved: ", path)
      TRUE
    },
    error = function(e) {
      warning("Could not save ", filename, ": ", conditionMessage(e))
      FALSE
    }
  )
}

safe_capture_output <- function(..., filename) {
  path <- file.path(output_dir, filename)
  expressions <- substitute(list(...))[-1L]

  tryCatch(
    {
      con <- file(path, open = "wt", encoding = "UTF-8")
      on.exit(close(con), add = TRUE)

      for (expr in expressions) {
        value <- eval(expr, envir = parent.frame())
        if (!is.null(value)) {
          capture.output(print(value), file = con)
        }
      }

      message("Saved: ", path)
      TRUE
    },
    error = function(e) {
      warning("Could not save ", filename, ": ", conditionMessage(e))
      FALSE
    }
  )
}

safe_save_diagnostics <- function(model, filename) {
  png_path <- file.path(output_dir, filename)

  png_ok <- tryCatch(
    {
      grDevices::png(
        filename = png_path,
        width = 1800,
        height = 1800,
        res = 220
      )
      graphics::par(mfrow = c(2, 2))
      graphics::plot(model)
      grDevices::dev.off()
      message("Saved: ", png_path)
      TRUE
    },
    error = function(e) {
      if (grDevices::dev.cur() > 1L) {
        try(grDevices::dev.off(), silent = TRUE)
      }
      FALSE
    }
  )

  if (png_ok) return(TRUE)

  # Portable fallback when the Windows PNG device is unavailable.
  pdf_path <- sub("\\.png$", ".pdf", png_path, ignore.case = TRUE)

  pdf_ok <- tryCatch(
    {
      grDevices::pdf(pdf_path, width = 8, height = 8)
      graphics::par(mfrow = c(2, 2))
      graphics::plot(model)
      grDevices::dev.off()
      message("PNG unavailable; diagnostics saved as PDF: ", pdf_path)
      TRUE
    },
    error = function(e) {
      if (grDevices::dev.cur() > 1L) {
        try(grDevices::dev.off(), silent = TRUE)
      }
      warning(
        "Diagnostic plot could not be saved, but the statistical analysis is complete. ",
        conditionMessage(e)
      )
      FALSE
    }
  )

  pdf_ok
}

output_dir <- get_output_dir()
cat("Output directory: ", output_dir, "\n", sep = "")

# 1. Input data ------------------------------------------------------

mcf7_wide <- data.frame(
  experiment = factor(1:4),
  check.names = FALSE,
  "3"           = c(0.423, 0.501, 0.512, 0.363),
  "1.5"         = c(0.396, 0.525, 0.468, 0.416),
  "0.75"        = c(0.632, 1.085, 0.875, 0.407),
  "0.375"       = c(0.666, 0.604, 0.671, 0.428),
  "0.1875"      = c(0.762, 1.167, 0.755, 1.013),
  "0.09375"     = c(0.983, 1.021, 0.835, 0.790),
  "0.046875"    = c(1.196, 1.292, 1.206, 1.173),
  "0.0234375"   = c(1.170, 1.110, 0.679, 0.392),
  "0.01171875"  = c(1.187, 1.111, 1.205, 0.730),
  "0.005859375" = c(1.226, 1.201, 1.198, 0.445),
  "0"           = c(1.304, 0.871, 1.207, 0.798)
)

dose_names <- setdiff(names(mcf7_wide), "experiment")

mcf7 <- reshape(
  mcf7_wide,
  varying = dose_names,
  v.names = "OD",
  timevar = "dose",
  times = dose_names,
  direction = "long"
)
rownames(mcf7) <- NULL

mcf7$experiment <- factor(mcf7$experiment)
mcf7$dose <- factor(mcf7$dose, levels = c("0", setdiff(dose_names, "0")))

stopifnot(
  nlevels(mcf7$experiment) == 4L,
  all(table(mcf7$experiment) == length(dose_names)),
  !anyNA(mcf7$OD),
  all(mcf7$OD > 0)
)

controls <- mcf7[mcf7$dose == "0", c("experiment", "OD")]
names(controls)[2] <- "control_OD"
mcf7 <- merge(mcf7, controls, by = "experiment", sort = FALSE)
mcf7$viability_percent <- 100 * mcf7$OD / mcf7$control_OD
mcf7$log_response_ratio <- log(mcf7$OD / mcf7$control_OD)

fit_mcf7 <- lm(OD ~ experiment + dose, data = mcf7)
anova_mcf7 <- anova(fit_mcf7)

dunnett_mcf7 <- glht(fit_mcf7, linfct = mcp(dose = "Dunnett"))
dunnett_summary_mcf7 <- summary(dunnett_mcf7)
dunnett_ci_mcf7 <- confint(dunnett_mcf7)
shapiro_mcf7 <- shapiro.test(residuals(fit_mcf7))

cat("\n================ MCF-7 BLOCKED ANOVA ================\n")
print(anova_mcf7)
cat("\n================ MCF-7 DUNNETT TESTS ================\n")
print(dunnett_summary_mcf7)
cat("\n========== MCF-7 SIMULTANEOUS 95% CONFIDENCE INTERVALS ==========\n")
print(dunnett_ci_mcf7)
cat("\n================ MCF-7 RESIDUAL NORMALITY ================\n")
print(shapiro_mcf7)

summary_fun <- function(x) {
  c(
    mean = mean(x),
    SD = sd(x),
    median = median(x),
    min = min(x),
    max = max(x),
    n = length(x)
  )
}

mcf7_summary <- aggregate(
  cbind(OD, viability_percent) ~ dose,
  data = mcf7,
  FUN = summary_fun
)

safe_write_csv(mcf7, "MCF7_long_data_blank_corrected.csv")
safe_write_csv(mcf7_summary, "MCF7_descriptive_summary.csv")

results_path <- file.path(output_dir, "MCF7_corrected_results.txt")
tryCatch(
  {
    sink(results_path)
    cat("MCF-7 blocked model: OD ~ experiment + dose\n\n")
    print(anova_mcf7)
    cat("\nDunnett contrasts\n")
    print(dunnett_summary_mcf7)
    cat("\nSimultaneous 95% confidence intervals\n")
    print(dunnett_ci_mcf7)
    cat("\nShapiro-Wilk test of residuals\n")
    print(shapiro_mcf7)
    sink()
    message("Saved: ", results_path)
  },
  error = function(e) {
    if (sink.number() > 0L) sink()
    warning("Could not save MCF-7 text output: ", conditionMessage(e))
  }
)

safe_save_diagnostics(fit_mcf7, "MCF7_model_diagnostics.png")
