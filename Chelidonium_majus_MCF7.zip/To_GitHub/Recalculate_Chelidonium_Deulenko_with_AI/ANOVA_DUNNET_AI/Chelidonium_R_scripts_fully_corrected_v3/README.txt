CHELIDONIUM MTT ANALYSIS — VERSION 3

How to run
----------
1. Unpack all files into one folder.
2. In R:

   setwd("~/R_new/Chelidonium_R_scripts_fully_corrected_v3")
   source("04_run_all.R")

3. Results will be written to:

   ~/Chelidonium_R_results

   This location is outside the protected Documents subfolder whenever possible.

Main fixes in v3
----------------
- Output files are written to a tested writable directory.
- Windows Controlled Folder Access no longer stops the analysis.
- PNG diagnostics automatically fall back to PDF.
- File-saving failures do not invalidate completed statistics.
- status is updated correctly after each script.
- The final all(status == "completed") check cannot fail because of NA values.
- The combined script no longer repeats MCF-7 Dunnett using a reduced dose set.
- Dunnett results appear only in the complete MCF-7 and lymphocyte analyses.
- Combined analysis reports only the valid overall response-profile interaction.

Statistical design
------------------
- Biological n = 4 independent experiments.
- Doses are repeated within experiment.
- Separate blocked models: OD ~ experiment + dose.
- Dunnett adjustment: each dose versus untreated control.
- MCF-7 and lymphocyte series are unpaired.
- Cross-cell interaction uses log(OD_dose / OD_control).
