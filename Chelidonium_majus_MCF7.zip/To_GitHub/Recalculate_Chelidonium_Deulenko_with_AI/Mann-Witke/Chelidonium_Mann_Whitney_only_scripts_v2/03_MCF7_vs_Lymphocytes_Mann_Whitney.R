# ================================================================
# Mann-Whitney U analysis
# Exact two-sided tests; raw and Holm-adjusted p-values
# ================================================================

get_output_dir <- function() {
  # Reuse the directory selected by 04_run_all.R when available.
  if (exists("analysis_output_dir", envir = .GlobalEnv, inherits = FALSE)) {
    candidate <- get("analysis_output_dir", envir = .GlobalEnv)

    ok <- tryCatch({
      dir.create(candidate, recursive = TRUE, showWarnings = FALSE)
      test_file <- file.path(
        candidate,
        paste0("write_test_", Sys.getpid(), ".tmp")
      )
      created <- file.create(test_file)
      if (isTRUE(created)) unlink(test_file)
      isTRUE(created)
    }, error = function(e) FALSE)

    if (ok) {
      return(normalizePath(candidate, winslash = "/", mustWork = FALSE))
    }
  }

  # Try several locations because Windows may protect Documents.
  candidates <- c(
    file.path(Sys.getenv("LOCALAPPDATA"), "Chelidonium_Mann_Whitney_results"),
    file.path(Sys.getenv("TEMP"), "Chelidonium_Mann_Whitney_results"),
    file.path(tempdir(), "Chelidonium_Mann_Whitney_results"),
    file.path(getwd(), "results")
  )

  candidates <- unique(candidates[nzchar(candidates)])

  for (candidate in candidates) {
    ok <- tryCatch({
      dir.create(candidate, recursive = TRUE, showWarnings = FALSE)
      test_file <- file.path(
        candidate,
        paste0("write_test_", Sys.getpid(), ".tmp")
      )
      created <- file.create(test_file)
      if (isTRUE(created)) unlink(test_file)
      isTRUE(created)
    }, error = function(e) FALSE)

    if (ok) {
      return(normalizePath(candidate, winslash = "/", mustWork = FALSE))
    }
  }

  stop(
    "No writable output directory could be created. ",
    "Try setting analysis_output_dir manually, for example: ",
    "analysis_output_dir <- 'C:/Temp/Chelidonium_Mann_Whitney_results'"
  )
}

output_dir <- get_output_dir()
cat("Output directory: ", output_dir, "\n", sep = "")

mann_whitney_result <- function(x, y, dose_label) {
  test <- stats::wilcox.test(
    x = x,
    y = y,
    alternative = "two.sided",
    paired = FALSE,
    exact = TRUE,
    correct = FALSE,
    conf.int = FALSE
  )

  n_x <- length(x)
  n_y <- length(y)

  # R reports the Mann-Whitney/Wilcoxon rank-sum statistic as W.
  # For wilcox.test with two samples, this is the U-type statistic.
  U <- unname(test$statistic)

  # Rank-biserial correlation oriented as dose minus control.
  # Negative values indicate lower observations in the dose group.
  rank_biserial <- (2 * U) / (n_x * n_y) - 1

  data.frame(
    dose = dose_label,
    n_dose = n_x,
    n_control = n_y,
    median_dose = median(x),
    median_control = median(y),
    median_difference = median(x) - median(y),
    U = U,
    rank_biserial = rank_biserial,
    p_raw = test$p.value,
    stringsAsFactors = FALSE
  )
}

mcf7_wide <- data.frame(
  experiment = 1:4,
  check.names = FALSE,
  "3"          = c(0.423, 0.501, 0.512, 0.363),
  "1.5"        = c(0.396, 0.525, 0.468, 0.416),
  "0.75"       = c(0.632, 1.085, 0.875, 0.407),
  "0.375"      = c(0.666, 0.604, 0.671, 0.428),
  "0.1875"     = c(0.762, 1.167, 0.755, 1.013),
  "0.09375"    = c(0.983, 1.021, 0.835, 0.790),
  "0.046875"   = c(1.196, 1.292, 1.206, 1.173),
  "0.0234375"  = c(1.170, 1.110, 0.679, 0.392),
  "0.01171875" = c(1.187, 1.111, 1.205, 0.730),
  "0"          = c(1.304, 0.871, 1.207, 0.798)
)

lymph_wide <- data.frame(
  experiment = 1:4,
  check.names = FALSE,
  "3"          = c(0.136, 0.125, 0.170, 0.156),
  "1.5"        = c(0.388, 0.385, 0.375, 0.341),
  "0.75"       = c(0.388, 0.441, 0.415, 0.397),
  "0.375"      = c(0.423, 0.488, 0.4337, 0.398),
  "0.1875"     = c(0.499, 0.482, 0.470, 0.387),
  "0.09375"    = c(0.397, 0.429, 0.386, 0.411),
  "0.046875"   = c(0.403, 0.401, 0.408, 0.4712),
  "0.0234375"  = c(0.449, 0.454, 0.414, 0.489),
  "0.01171875" = c(0.431, 0.496, 0.437, 0.456),
  "0"          = c(0.429, 0.453, 0.479, 0.3987)
)

common_doses <- intersect(
  setdiff(names(mcf7_wide), c("experiment", "0")),
  setdiff(names(lymph_wide), c("experiment", "0"))
)

mcf7_control <- mcf7_wide[["0"]]
lymph_control <- lymph_wide[["0"]]

results <- do.call(
  rbind,
  lapply(
    common_doses,
    function(dose_name) {
      # Log response ratios normalise each experiment to its own control.
      mcf7_lrr <- log(mcf7_wide[[dose_name]] / mcf7_control)
      lymph_lrr <- log(lymph_wide[[dose_name]] / lymph_control)

      test <- stats::wilcox.test(
        x = mcf7_lrr,
        y = lymph_lrr,
        alternative = "two.sided",
        paired = FALSE,
        exact = TRUE,
        correct = FALSE
      )

      U <- unname(test$statistic)
      n1 <- length(mcf7_lrr)
      n2 <- length(lymph_lrr)

      data.frame(
        dose = dose_name,
        n_MCF7 = n1,
        n_lymphocytes = n2,
        median_log_ratio_MCF7 = median(mcf7_lrr),
        median_log_ratio_lymphocytes = median(lymph_lrr),
        median_viability_MCF7 = 100 * median(exp(mcf7_lrr)),
        median_viability_lymphocytes = 100 * median(exp(lymph_lrr)),
        U = U,
        rank_biserial = (2 * U) / (n1 * n2) - 1,
        p_raw = test$p.value,
        stringsAsFactors = FALSE
      )
    }
  )
)

results$p_holm <- p.adjust(results$p_raw, method = "holm")
results$significant_raw_0_05 <- results$p_raw < 0.05
results$significant_holm_0_05 <- results$p_holm < 0.05

cat("\n========== MCF-7 VS LYMPHOCYTES: MANN-WHITNEY TESTS ==========\n")
print(results, row.names = FALSE)

cat(
  "\nThese between-cell tests are compatible with the unpaired cell-series,\n",
  "but n = 4 per cell type gives very low power and coarse exact p-values.\n",
  "No single Mann-Whitney test provides an omnibus cell-by-dose interaction.\n",
  sep = ""
)

write.csv(
  results,
  file.path(output_dir, "MCF7_vs_Lymphocytes_Mann_Whitney.csv"),
  row.names = FALSE
)

capture.output(
  results,
  cat(
    "\nInterpretation:\n",
    "Tests compare within-experiment log response ratios between the two\n",
    "unpaired cell-series at each shared non-zero dose.\n"
  ),
  file = file.path(output_dir, "MCF7_vs_Lymphocytes_Mann_Whitney.txt")
)
