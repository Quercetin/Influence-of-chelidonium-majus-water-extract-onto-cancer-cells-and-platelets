# ================================================================
# Run all Mann-Whitney analyses using a writable Windows directory
# ================================================================

scripts <- c(
  "01_MCF7_Mann_Whitney_vs_control.R",
  "02_Lymphocytes_Mann_Whitney_vs_control.R",
  "03_MCF7_vs_Lymphocytes_Mann_Whitney.R"
)

missing <- scripts[!file.exists(scripts)]
if (length(missing) > 0L) {
  stop(
    "Missing script files: ",
    paste(missing, collapse = ", "),
    "\nCurrent working directory: ",
    getwd()
  )
}

choose_output_dir <- function() {
  candidates <- c(
    file.path(Sys.getenv("LOCALAPPDATA"), "Chelidonium_Mann_Whitney_results"),
    file.path(Sys.getenv("TEMP"), "Chelidonium_Mann_Whitney_results"),
    file.path(tempdir(), "Chelidonium_Mann_Whitney_results"),
    file.path(getwd(), "results")
  )

  candidates <- unique(candidates[nzchar(candidates)])

  for (candidate in candidates) {
    ok <- tryCatch({
      dir.create(candidate, recursive = TRUE, showWarnings = FALSE)
      test_file <- file.path(
        candidate,
        paste0("write_test_", Sys.getpid(), ".tmp")
      )
      created <- file.create(test_file)
      if (isTRUE(created)) unlink(test_file)
      isTRUE(created)
    }, error = function(e) FALSE)

    if (ok) {
      return(normalizePath(candidate, winslash = "/", mustWork = FALSE))
    }
  }

  stop(
    "No writable output directory was found. ",
    "Create C:/Temp and set: ",
    "analysis_output_dir <- 'C:/Temp/Chelidonium_Mann_Whitney_results'"
  )
}

analysis_output_dir <- choose_output_dir()
assign("analysis_output_dir", analysis_output_dir, envir = .GlobalEnv)

cat(
  "Script directory: ",
  normalizePath(getwd(), winslash = "/", mustWork = FALSE),
  "\n",
  sep = ""
)
cat("Output directory: ", analysis_output_dir, "\n", sep = "")

status <- setNames(rep("not started", length(scripts)), scripts)

for (script in scripts) {
  cat("\n\nRUNNING: ", script, "\n", sep = "")

  result <- tryCatch(
    {
      source(script, echo = FALSE, local = globalenv())
      "completed"
    },
    error = function(e) {
      message("ERROR IN ", script, ": ", conditionMessage(e))
      paste0("failed: ", conditionMessage(e))
    }
  )

  status[[script]] <- result
}

cat("\n================ FINAL STATUS ================\n")
print(status)

if (isTRUE(all(status == "completed"))) {
  cat("\nAll Mann-Whitney analyses completed successfully.\n")
} else {
  cat("\nAt least one script failed. Review the status above.\n")
}

cat("\nOutput directory:\n", analysis_output_dir, "\n", sep = "")
