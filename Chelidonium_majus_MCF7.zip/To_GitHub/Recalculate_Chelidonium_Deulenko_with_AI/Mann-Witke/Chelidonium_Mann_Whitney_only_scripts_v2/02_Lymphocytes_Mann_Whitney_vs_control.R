# ================================================================
# Mann-Whitney U analysis
# Exact two-sided tests; raw and Holm-adjusted p-values
# ================================================================

get_output_dir <- function() {
  # Reuse the directory selected by 04_run_all.R when available.
  if (exists("analysis_output_dir", envir = .GlobalEnv, inherits = FALSE)) {
    candidate <- get("analysis_output_dir", envir = .GlobalEnv)

    ok <- tryCatch({
      dir.create(candidate, recursive = TRUE, showWarnings = FALSE)
      test_file <- file.path(
        candidate,
        paste0("write_test_", Sys.getpid(), ".tmp")
      )
      created <- file.create(test_file)
      if (isTRUE(created)) unlink(test_file)
      isTRUE(created)
    }, error = function(e) FALSE)

    if (ok) {
      return(normalizePath(candidate, winslash = "/", mustWork = FALSE))
    }
  }

  # Try several locations because Windows may protect Documents.
  candidates <- c(
    file.path(Sys.getenv("LOCALAPPDATA"), "Chelidonium_Mann_Whitney_results"),
    file.path(Sys.getenv("TEMP"), "Chelidonium_Mann_Whitney_results"),
    file.path(tempdir(), "Chelidonium_Mann_Whitney_results"),
    file.path(getwd(), "results")
  )

  candidates <- unique(candidates[nzchar(candidates)])

  for (candidate in candidates) {
    ok <- tryCatch({
      dir.create(candidate, recursive = TRUE, showWarnings = FALSE)
      test_file <- file.path(
        candidate,
        paste0("write_test_", Sys.getpid(), ".tmp")
      )
      created <- file.create(test_file)
      if (isTRUE(created)) unlink(test_file)
      isTRUE(created)
    }, error = function(e) FALSE)

    if (ok) {
      return(normalizePath(candidate, winslash = "/", mustWork = FALSE))
    }
  }

  stop(
    "No writable output directory could be created. ",
    "Try setting analysis_output_dir manually, for example: ",
    "analysis_output_dir <- 'C:/Temp/Chelidonium_Mann_Whitney_results'"
  )
}

output_dir <- get_output_dir()
cat("Output directory: ", output_dir, "\n", sep = "")

mann_whitney_result <- function(x, y, dose_label) {
  test <- stats::wilcox.test(
    x = x,
    y = y,
    alternative = "two.sided",
    paired = FALSE,
    exact = TRUE,
    correct = FALSE,
    conf.int = FALSE
  )

  n_x <- length(x)
  n_y <- length(y)

  # R reports the Mann-Whitney/Wilcoxon rank-sum statistic as W.
  # For wilcox.test with two samples, this is the U-type statistic.
  U <- unname(test$statistic)

  # Rank-biserial correlation oriented as dose minus control.
  # Negative values indicate lower observations in the dose group.
  rank_biserial <- (2 * U) / (n_x * n_y) - 1

  data.frame(
    dose = dose_label,
    n_dose = n_x,
    n_control = n_y,
    median_dose = median(x),
    median_control = median(y),
    median_difference = median(x) - median(y),
    U = U,
    rank_biserial = rank_biserial,
    p_raw = test$p.value,
    stringsAsFactors = FALSE
  )
}

lymph_wide <- data.frame(
  check.names = FALSE,
  "3"          = c(0.136, 0.125, 0.170, 0.156),
  "1.5"        = c(0.388, 0.385, 0.375, 0.341),
  "0.75"       = c(0.388, 0.441, 0.415, 0.397),
  "0.375"      = c(0.423, 0.488, 0.4337, 0.398),
  "0.1875"     = c(0.499, 0.482, 0.470, 0.387),
  "0.09375"    = c(0.397, 0.429, 0.386, 0.411),
  "0.046875"   = c(0.403, 0.401, 0.408, 0.4712),
  "0.0234375"  = c(0.449, 0.454, 0.414, 0.489),
  "0.01171875" = c(0.431, 0.496, 0.437, 0.456),
  "0"          = c(0.429, 0.453, 0.479, 0.3987)
)

control <- lymph_wide[["0"]]
dose_names <- setdiff(names(lymph_wide), "0")

results <- do.call(
  rbind,
  lapply(
    dose_names,
    function(dose_name) {
      mann_whitney_result(
        x = lymph_wide[[dose_name]],
        y = control,
        dose_label = dose_name
      )
    }
  )
)

results$p_holm <- p.adjust(results$p_raw, method = "holm")
results$significant_raw_0_05 <- results$p_raw < 0.05
results$significant_holm_0_05 <- results$p_holm < 0.05

cat("\n================ LYMPHOCYTE MANN-WHITNEY TESTS ================\n")
print(results, row.names = FALSE)

cat(
  "\nWARNING: dose and control values came from the same experiments.\n",
  "Mann-Whitney ignores this pairing and is not the preferred primary test.\n",
  sep = ""
)

write.csv(
  results,
  file.path(output_dir, "Lymphocytes_Mann_Whitney_vs_control.csv"),
  row.names = FALSE
)

capture.output(
  results,
  cat(
    "\nInterpretation warning:\n",
    "Mann-Whitney assumes independent samples, whereas dose and control\n",
    "were measured within the same independent experiments.\n"
  ),
  file = file.path(output_dir, "Lymphocytes_Mann_Whitney_vs_control.txt")
)
