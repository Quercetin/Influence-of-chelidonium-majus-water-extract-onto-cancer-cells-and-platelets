MANN-WHITNEY-ONLY SENSITIVITY ANALYSIS
Chelidonium majus MTT data

IMPORTANT STATISTICAL WARNING
-----------------------------
The Mann-Whitney U test assumes independent samples. In the present design,
each dose and its untreated control were measured within the same four
independent experiments. Therefore dose-versus-control observations are paired,
not independent.

Consequently:
- Scripts 01 and 02 are provided only because the user explicitly requested
  Mann-Whitney-only analyses.
- They should be described as exploratory/sensitivity analyses.
- They should not replace the blocked Dunnett analysis in the manuscript.
- A paired Wilcoxon signed-rank test would be the more appropriate
  non-parametric two-condition test.
- For an overall non-parametric repeated-dose analysis, Friedman-type methods
  would be more appropriate.

Script 03 compares normalised MCF-7 and lymphocyte responses at each shared
dose. These cell-series are unpaired, so Mann-Whitney is appropriate for those
between-cell comparisons. However, with n = 4 versus n = 4, statistical power
is very low and exact two-sided p-values are coarse.

Multiple testing
----------------
All scripts report:
- raw exact Mann-Whitney p-values;
- Holm-adjusted p-values across the family of tested doses.

Holm adjustment is not a different statistical criterion; it controls the
family-wise error rate across repeated Mann-Whitney tests.

Expected consequence of n = 4
-----------------------------
For two independent groups of four observations, the smallest possible
two-sided exact Mann-Whitney p-value is 0.028571. Therefore even complete
separation cannot remain significant after correction across 9-10 doses.

Files
-----
01_MCF7_Mann_Whitney_vs_control.R
02_Lymphocytes_Mann_Whitney_vs_control.R
03_MCF7_vs_Lymphocytes_Mann_Whitney.R
04_run_all.R
05_STATISTICAL_ASSESSMENT.txt

Version 2 automatically selects a writable Windows output directory.
