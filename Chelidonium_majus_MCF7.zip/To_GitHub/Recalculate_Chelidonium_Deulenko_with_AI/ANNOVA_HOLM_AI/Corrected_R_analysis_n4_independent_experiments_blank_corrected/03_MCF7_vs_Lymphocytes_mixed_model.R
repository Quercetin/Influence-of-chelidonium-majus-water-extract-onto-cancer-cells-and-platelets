# Combined MCF-7 versus lymphocyte analysis.
# Four independent experiments per cell type.
# install.packages(c("lme4","lmerTest","emmeans"))
library(lme4)
library(lmerTest)
library(emmeans)

source("01_MCF7_repeated_experiments_Dunnett.R")
mc_dat <- dat
mc_dat$cell <- "MCF7"

source("02_Lymphocytes_repeated_experiments_Dunnett.R")
ly_dat <- dat
ly_dat$cell <- "Lymphocytes"

common_doses <- intersect(as.character(unique(mc_dat$dose)),
                          as.character(unique(ly_dat$dose)))
combined <- rbind(
  mc_dat[as.character(mc_dat$dose) %in% common_doses,],
  ly_dat[as.character(ly_dat$dose) %in% common_doses,]
)
combined$cell <- factor(combined$cell)
combined$dose <- factor(as.character(combined$dose),
                        levels=c("3","1.5","0.75","0.375","0.1875",
                                 "0.09375","0.046875","0.0234375",
                                 "0.01171875","0"))

# Set TRUE only if experiment 1 for MCF-7 and experiment 1 for lymphocytes
# were performed in the same experimental run and should be treated as paired.
paired_between_cell_types <- FALSE

if(paired_between_cell_types){
  combined$experiment_global <- factor(combined$experiment)
  fit_combined <- lmer(viability_percent ~ cell*dose +
                         (1|experiment_global), data=combined)
} else {
  combined$experiment_nested <- interaction(combined$cell,
                                             combined$experiment,drop=TRUE)
  fit_combined <- lmer(viability_percent ~ cell*dose +
                         (1|experiment_nested), data=combined)
}

print(anova(fit_combined,type=3))

# Cell-type differences at each dose.
emm_cell <- emmeans(fit_combined, ~ cell | dose)
cell_contrasts <- as.data.frame(pairs(emm_cell,adjust="none"))
# One Holm family across all dose-specific comparisons:
cell_contrasts$p_holm_global <- p.adjust(cell_contrasts$p.value,method="holm")
print(cell_contrasts)

# Because controls are normalized to 100% in each experiment, dose-vs-control
# inference is obtained more cleanly from the separate raw-OD blocked models.
write.csv(cell_contrasts,
          "MCF7_vs_Lymphocytes_cell_contrasts_global_Holm.csv",
          row.names=FALSE)
write.csv(combined,"combined_normalized_long_n4.csv",row.names=FALSE)
capture.output(anova(fit_combined,type=3),cell_contrasts,
               file="MCF7_vs_Lymphocytes_corrected_output.txt")
