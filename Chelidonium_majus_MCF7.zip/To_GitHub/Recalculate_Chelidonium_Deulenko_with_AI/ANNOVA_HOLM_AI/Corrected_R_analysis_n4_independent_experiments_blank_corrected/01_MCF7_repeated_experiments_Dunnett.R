# MCF-7: 4 independent experiments, repeated concentrations within each experiment
# Required packages:
# install.packages(c("multcomp","emmeans","car"))
library(multcomp)
library(emmeans)
library(car)

mc_w <- data.frame(
  experiment=factor(1:4),
  check.names=FALSE,
  "3"=c(0.423,0.501,0.512,0.363),
  "1.5"=c(0.396,0.525,0.468,0.416),
  "0.75"=c(0.632,1.085,0.875,0.407),
  "0.375"=c(0.666,0.604,0.671,0.428),
  "0.1875"=c(0.762,1.167,0.755,1.013),
  "0.09375"=c(0.983,1.021,0.835,0.790),
  "0.046875"=c(1.196,1.292,1.206,1.173),
  "0.0234375"=c(1.170,1.110,0.679,0.392),
  "0.01171875"=c(1.187,1.111,1.205,0.730),
  "0.005859375"=c(1.226,1.201,1.198,0.445),
  "0"=c(1.304,0.871,1.207,0.798)
)

dose_names <- names(mc_w)[-1]
dat <- reshape(mc_w, varying=dose_names, v.names="OD",
               timevar="dose", times=dose_names, direction="long")
rownames(dat) <- NULL
dat$dose <- factor(dat$dose, levels=dose_names)
dat$experiment <- factor(dat$experiment)

# OD values are already blank-corrected.
# Normalize only to the untreated control from the SAME independent experiment.
ctrl <- dat[dat$dose=="0",c("experiment","OD")]
names(ctrl)[2] <- "control_OD"
dat <- merge(dat,ctrl,by="experiment")
dat$viability_percent <- 100*dat$OD/dat$control_OD

# Blocked repeated-experiment model. Experiment is a blocking factor.
fit <- lm(OD ~ experiment + dose, data=dat)
print(anova(fit))

# Dunnett: each dose versus 0 mg/ml, adjusted for experiment block.
dat$dose <- relevel(dat$dose, ref="0")
fit_dunnett <- lm(OD ~ experiment + dose, data=dat)
dunnett <- glht(fit_dunnett, linfct=mcp(dose="Dunnett"))
print(summary(dunnett))
print(confint(dunnett))

# Descriptive statistics across four independent experiments.
desc <- aggregate(cbind(OD,viability_percent) ~ dose,dat,
                  function(x)c(mean=mean(x),SD=sd(x),n=length(x)))
print(desc)

# Diagnostics
par(mfrow=c(2,2)); plot(fit_dunnett); par(mfrow=c(1,1))
print(shapiro.test(residuals(fit_dunnett)))
# With n=4, diagnostic tests have low power; inspect residual plots too.

write.csv(dat,"MCF7_long_normalized_n4.csv",row.names=FALSE)
capture.output(anova(fit),summary(dunnett),confint(dunnett),
               file="MCF7_corrected_output.txt")
