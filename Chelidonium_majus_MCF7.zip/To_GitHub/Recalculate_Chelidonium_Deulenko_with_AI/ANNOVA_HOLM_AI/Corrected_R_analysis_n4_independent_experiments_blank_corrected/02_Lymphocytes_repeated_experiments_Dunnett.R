# Lymphocytes: 4 independent experiments, repeated concentrations within each experiment
# install.packages(c("multcomp","emmeans","car"))
library(multcomp)
library(emmeans)
library(car)

ly_w <- data.frame(
  experiment=factor(1:4),
  check.names=FALSE,
  "3"=c(0.136,0.125,0.170,0.156),
  "1.5"=c(0.388,0.385,0.375,0.341),
  "0.75"=c(0.388,0.441,0.415,0.397),
  "0.375"=c(0.423,0.488,0.4337,0.398),
  "0.1875"=c(0.499,0.482,0.470,0.387),
  "0.09375"=c(0.397,0.429,0.386,0.411),
  "0.046875"=c(0.403,0.401,0.408,0.4712),
  "0.0234375"=c(0.449,0.454,0.414,0.489),
  "0.01171875"=c(0.431,0.496,0.437,0.456),
  "0"=c(0.429,0.453,0.479,0.3987)
)

dose_names <- names(ly_w)[-1]
dat <- reshape(ly_w, varying=dose_names, v.names="OD",
               timevar="dose", times=dose_names, direction="long")
rownames(dat) <- NULL
dat$dose <- factor(dat$dose, levels=dose_names)
dat$experiment <- factor(dat$experiment)

ctrl <- dat[dat$dose=="0",c("experiment","OD")]
names(ctrl)[2] <- "control_OD"
dat <- merge(dat,ctrl,by="experiment")
dat$viability_percent <- 100*dat$OD/dat$control_OD

fit <- lm(OD ~ experiment + dose, data=dat)
print(anova(fit))

dat$dose <- relevel(dat$dose, ref="0")
fit_dunnett <- lm(OD ~ experiment + dose, data=dat)
dunnett <- glht(fit_dunnett, linfct=mcp(dose="Dunnett"))
print(summary(dunnett))
print(confint(dunnett))

desc <- aggregate(cbind(OD,viability_percent) ~ dose,dat,
                  function(x)c(mean=mean(x),SD=sd(x),n=length(x)))
print(desc)

par(mfrow=c(2,2)); plot(fit_dunnett); par(mfrow=c(1,1))
print(shapiro.test(residuals(fit_dunnett)))

write.csv(dat,"Lymphocytes_long_normalized_n4.csv",row.names=FALSE)
capture.output(anova(fit),summary(dunnett),confint(dunnett),
               file="Lymphocytes_corrected_output.txt")
