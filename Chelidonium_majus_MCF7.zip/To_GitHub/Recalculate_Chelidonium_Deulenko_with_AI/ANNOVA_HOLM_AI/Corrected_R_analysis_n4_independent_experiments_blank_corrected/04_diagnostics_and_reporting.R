# Reporting and diagnostic guidance
# Report:
# - n = 4 independent experiments
# - individual data points
# - mean ± SD, not only SEM
# - blocked/repeated-measures design
# - Dunnett-adjusted estimates and 95% confidence intervals
# - exact adjusted p-values
#
# Avoid claiming that all wells are independent.
# Avoid comparing raw MTT OD directly between cell types.
# Normalize each independent experiment to its own untreated control.
# Use raw OD with experiment blocking for within-cell Dunnett tests.
#
# Sensitivity analysis for non-normal paired differences:
# For a selected dose:
# wilcox.test(OD[dose=="3"], OD[dose=="0"], paired=TRUE, exact=FALSE)
# With n=4 this test has very low resolution and should be supplementary.
