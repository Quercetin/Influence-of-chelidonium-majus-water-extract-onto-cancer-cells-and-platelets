### 0. Packages -------------------------------------------------------------

# Install once if needed:
# install.packages("multcomp")
# install.packages("emmeans")

library(multcomp)
library(emmeans)

### 1. Read wide-format data -----------------------------------------------

# Each file: 4 rows (replicates) × 11 columns (doses)
# Header row = doses, e.g. 3, 1.5, ..., 0   (no "mg/ml" in names)

# 1) Inpute data (wide format), in columns,  MCF7, control
mc_w <- data.frame(
  check.names = FALSE,
  "3"          = c(0.423, 0.501, 0.512, 0.363),
  "1.5"        = c(0.396, 0.525, 0.468, 0.416),
  "0.75"       = c(0.632, 1.085, 0.875, 0.407),
  "0.375"      = c(0.666, 0.604, 0.671, 0.428),
  "0.1875"     = c(0.762, 1.167, 0.755, 1.013),
  "0.09375"    = c(0.983, 1.021, 0.835, 0.79),
  "0.046875"   = c(1.196, 1.292, 1.206, 1.173),
  "0.0234375"  = c(1.17, 1.11, 0.679, 0.392),
  "0.01171875" = c(1.187, 1.111, 1.205, 0.73),
  "0.005859375"= c(1.226, 1.201, 1.198, 0.445),
  "0"          = c(1.304, 0.871, 1.207, 0.798)  # control
)


ly_w <-data.frame( 
  check.names = FALSE,
  "3"          = c(0.136, 0.125, 0.17, 0.156),
  "1.5"        = c(0.388, 0.385, 0.375,0.341),
  "0.75"       = c(0.388, 0.441, 0.415, 0.397),
  "0.375"      = c(0.423,0.488, 0.4337,0.398),
  "0.1875"     = c(0.499,0.482, 0.47, 0.387),
  "0.09375"    = c(0.397, 0.429, 0.386, 0.411),
  "0.046875"   = c(0.403, 0.401, 0.408, 0.4712),
  "0.0234375"  = c(0.449, 0.454, 0.414, 0.489), 
  "0.01171875" = c(0.431, 0.496, 0.437, 0.456), 
  "0"          = c(0.429, 0.453, 0.479, 0.3987)  # control
)

# remove dose 0.005859375 з MCF7
mc_w <- mc_w[ , !(names(mc_w) == "0.005859375")]

# Control: names of colums must be the same
names(mc_w)
names(ly_w)


# Optional: check that dose columns are identical
stopifnot(identical(names(mc_w), names(ly_w)))

### 2. Convert wide → long and add cell-type factor ------------------------

mc_long <- stack(mc_w)
ly_long <- stack(ly_w)

mc_long$cell <- "MCF7"
ly_long$cell <- "Lymphocytes"

# Combine
dat <- rbind(mc_long, ly_long)
colnames(dat)[1:2] <- c("value", "dose")

# Factors
dat$cell <- factor(dat$cell)              # MCF7 vs Lymphocytes
dat$dose <- factor(dat$dose, 
                   levels = names(mc_w))  # keep dose order; “0” is last

str(dat)  # quick check

### 3. Two-way ANOVA: value ~ cell * dose ----------------------------------

fit2 <- aov(value ~ cell * dose, data = dat)

summary(fit2)          # Type I ANOVA table
anova(fit2)            # same, in another format

# The key line here is "cell:dose"
# If p-value for cell:dose < 0.05 → interaction is significant.

### 4. Post-hoc contrasts IF interaction is significant --------------------
# (Cell-type differences at each dose; Dunnett-type logic is less natural
#  here, so we use emmeans with multiple-comparison adjustment.)

# 4A. Differences between cell types at each dose
emm_cell_by_dose <- emmeans(fit2, ~ cell | dose)      # means of cell type within each dose
pairs_cell_by_dose <- pairs(emm_cell_by_dose,
                            adjust = "holm")          # or "bonferroni", "tukey", etc.

pairs_cell_by_dose

# Interpretation:
# For each dose (3, 1.5, ... , 0) you get:
#   estimate = MCF7 - Lymphocytes
#   p.value (adjusted) for “MCF7 vs Lymphocytes” at that dose.

### 5. Optional: dose effects within each cell type ------------------------

# Only if you also want to know, within MCF7 or within Lymphocytes,
# which doses differ from each other (e.g. vs control):

emm_dose_by_cell <- emmeans(fit2, ~ dose | cell)

# Pairwise dose comparisons within each cell type:
pairs_dose_by_cell <- pairs(emm_dose_by_cell,
                            adjust = "tukey")   # or "holm"

pairs_dose_by_cell

# Check dose levels
levels(dat$dose)

# Find which level is "0" (control)
control_index <- which(levels(dat$dose) == "0")
control_index

# If you specifically want “each dose vs control (0 mg/ml)” within each cell:
contrast_vs_control <- contrast(
  emm_dose_by_cell,
  method = "trt.vs.ctrl",
  ref    = control_index,   # або просто 10
  adjust = "dunnett"
)

contrast_vs_control