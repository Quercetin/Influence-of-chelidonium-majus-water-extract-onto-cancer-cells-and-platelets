# install.packages("multcomp") 

library(multcomp)

# 1) Impute data (wide format), in columns,  Lymphocyte, control
dat_L <- data.frame(
  check.names = FALSE,
  "3"          = c(0.136, 0.125, 0.17, 0.156),
  "1.5"        = c(0.388, 0.385, 0.375,0.341),
  "0.75"       = c(0.388, 0.441, 0.415, 0.397),
  "0.375"      = c(0.423,0.488, 0.4337,0.398),
  "0.1875"     = c(0.499,0.482, 0.47, 0.387),
  "0.09375"    = c(0.397, 0.429, 0.386, 0.411),
  "0.046875"   = c(0.403, 0.401, 0.408, 0.4712),
  "0.0234375"  = c(0.449, 0.454, 0.414, 0.489), 
  "0.01171875" = c(0.431, 0.496, 0.437, 0.456), 
  "0"          = c(0.429, 0.453, 0.479, 0.3987)  # control
)

# View column names (optional, for control)
names(dat_L)

# 2) Convert wide → long
dat <- stack(dat_L)
colnames(dat) <- c("value", "group")

# 3) Make group a factor and set Control (last column) as ref
dat$group <- factor(dat$group)
control_name <- names(dat_L)[ncol(dat_L)]  # the name of the last column, here "0"
dat$group <- relevel(dat$group, ref = control_name)

# Check levels (optional)
levels(dat$group)

# 4) ANOVA
fit <- aov(value ~ group, data = dat)
summary(fit)

# 5) Dunnett vs control
res <- glht(fit, linfct = mcp(group = "Dunnett"))
summary(res)