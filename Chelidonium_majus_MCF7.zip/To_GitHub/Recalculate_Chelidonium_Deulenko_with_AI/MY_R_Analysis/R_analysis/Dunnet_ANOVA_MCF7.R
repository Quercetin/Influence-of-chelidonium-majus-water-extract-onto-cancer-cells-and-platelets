# install.packages("multcomp") 

library(multcomp)

# 1) Inpute data (wide format), in columns,  MCF7, control
dat_w <- data.frame(
  check.names = FALSE,
  "3"          = c(0.423, 0.501, 0.512, 0.363),
  "1.5"        = c(0.396, 0.525, 0.468, 0.416),
  "0.75"       = c(0.632, 1.085, 0.875, 0.407),
  "0.375"      = c(0.666, 0.604, 0.671, 0.428),
  "0.1875"     = c(0.762, 1.167, 0.755, 1.013),
  "0.09375"    = c(0.983, 1.021, 0.835, 0.79),
  "0.046875"   = c(1.196, 1.292, 1.206, 1.173),
  "0.0234375"  = c(1.17, 1.11, 0.679, 0.392),
  "0.01171875" = c(1.187, 1.111, 1.205, 0.73),
  "0.005859375"= c(1.226, 1.201, 1.198, 0.445),
  "0"          = c(1.304, 0.871, 1.207, 0.798)  # control
  )

# Look column names (optional, for control)
names(dat_w)

# 2) Convert wide → long
dat <- stack(dat_w)
colnames(dat) <- c("value", "group")

# 3) Make group a factor and set Control (last column) as ref
dat$group <- factor(dat$group)
control_name <- names(dat_w)[ncol(dat_w)]  # the column name, here "0"
dat$group <- relevel(dat$group, ref = control_name)

# Check levels (optional)
levels(dat$group)

# 4) ANOVA
fit <- aov(value ~ group, data = dat)
summary(fit)

# 5) Dunnett vs control
res <- glht(fit, linfct = mcp(group = "Dunnett"))
summary(res)

