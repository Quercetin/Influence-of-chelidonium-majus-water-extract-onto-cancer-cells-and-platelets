# ================================================================
# Non-parametric analysis: Friedman + Wilcoxon
# Results are saved directly in the current working directory.
# ================================================================

get_output_dir <- function() {
  out <- getwd()

  if (!dir.exists(out)) {
    stop("Working directory does not exist: ", out)
  }

  test_file <- file.path(
    out,
    paste0("write_test_", Sys.getpid(), ".tmp")
  )

  created <- suppressWarnings(file.create(test_file))

  if (!isTRUE(created)) {
    stop(
      "R cannot write to the current working directory: ",
      out,
      "\nMove the scripts to a writable folder, for example C:/Rwork/..."
    )
  }

  unlink(test_file)
  normalizePath(out, winslash = "/", mustWork = TRUE)
}

output_dir <- get_output_dir()
cat("Output directory: ", output_dir, "\n", sep = "")

paired_wilcoxon_safe <- function(x, y) {
  # Exact test is attempted first. If ties or zero differences prevent
  # exact inference, R automatically falls back to the normal approximation.
  warning_message <- NULL

  result <- withCallingHandlers(
    tryCatch(
      stats::wilcox.test(
        x = x,
        y = y,
        paired = TRUE,
        alternative = "two.sided",
        exact = TRUE,
        correct = FALSE,
        conf.int = FALSE
      ),
      error = function(e) NULL
    ),
    warning = function(w) {
      warning_message <<- conditionMessage(w)
      invokeRestart("muffleWarning")
    }
  )

  if (is.null(result) || !is.null(warning_message)) {
    result <- stats::wilcox.test(
      x = x,
      y = y,
      paired = TRUE,
      alternative = "two.sided",
      exact = FALSE,
      correct = FALSE,
      conf.int = FALSE
    )
    exact_used <- FALSE
  } else {
    exact_used <- TRUE
  }

  list(test = result, exact_used = exact_used)
}

rank_biserial_paired <- function(differences) {
  differences <- differences[differences != 0]

  if (length(differences) == 0L) {
    return(0)
  }

  ranks <- rank(abs(differences), ties.method = "average")
  w_plus <- sum(ranks[differences > 0])
  w_minus <- sum(ranks[differences < 0])

  (w_plus - w_minus) / (w_plus + w_minus)
}

mcf7_wide <- data.frame(
  experiment = factor(1:4),
  check.names = FALSE,
  "3"           = c(0.423, 0.501, 0.512, 0.363),
  "1.5"         = c(0.396, 0.525, 0.468, 0.416),
  "0.75"        = c(0.632, 1.085, 0.875, 0.407),
  "0.375"       = c(0.666, 0.604, 0.671, 0.428),
  "0.1875"      = c(0.762, 1.167, 0.755, 1.013),
  "0.09375"     = c(0.983, 1.021, 0.835, 0.790),
  "0.046875"    = c(1.196, 1.292, 1.206, 1.173),
  "0.0234375"   = c(1.170, 1.110, 0.679, 0.392),
  "0.01171875"  = c(1.187, 1.111, 1.205, 0.730),
  "0.005859375" = c(1.226, 1.201, 1.198, 0.445),
  "0"           = c(1.304, 0.871, 1.207, 0.798)
)

dose_names <- setdiff(names(mcf7_wide), "experiment")
dose_matrix <- as.matrix(mcf7_wide[, dose_names, drop = FALSE])

# 1. Overall repeated-dose effect: Friedman test ---------------------

friedman_mcf7 <- stats::friedman.test(dose_matrix)

cat("\n================ MCF-7 FRIEDMAN TEST ================\n")
print(friedman_mcf7)

# Kendall's W as an omnibus effect size
n_blocks <- nrow(dose_matrix)
k_conditions <- ncol(dose_matrix)
kendall_w <- unname(friedman_mcf7$statistic) /
  (n_blocks * (k_conditions - 1))

cat("\nKendall's W =", kendall_w, "\n")

# 2. Paired Wilcoxon: each dose vs corresponding control ------------

control <- mcf7_wide[["0"]]
treatment_doses <- setdiff(dose_names, "0")

wilcoxon_results <- do.call(
  rbind,
  lapply(
    treatment_doses,
    function(dose_name) {
      dose_values <- mcf7_wide[[dose_name]]
      differences <- dose_values - control
      wt <- paired_wilcoxon_safe(dose_values, control)

      data.frame(
        dose = dose_name,
        n_pairs = length(differences),
        median_dose = median(dose_values),
        median_control = median(control),
        median_paired_difference = median(differences),
        mean_paired_difference = mean(differences),
        V = unname(wt$test$statistic),
        rank_biserial_paired = rank_biserial_paired(differences),
        p_raw = wt$test$p.value,
        exact_used = wt$exact_used,
        stringsAsFactors = FALSE
      )
    }
  )
)

wilcoxon_results$p_holm <- p.adjust(
  wilcoxon_results$p_raw,
  method = "holm"
)
wilcoxon_results$significant_raw_0_05 <-
  wilcoxon_results$p_raw < 0.05
wilcoxon_results$significant_holm_0_05 <-
  wilcoxon_results$p_holm < 0.05

cat("\n========== MCF-7 PAIRED WILCOXON VS CONTROL ==========\n")
print(wilcoxon_results, row.names = FALSE)

friedman_table <- data.frame(
  test = "Friedman",
  chi_squared = unname(friedman_mcf7$statistic),
  df = unname(friedman_mcf7$parameter),
  p_value = friedman_mcf7$p.value,
  kendall_W = kendall_w
)

write.csv(
  friedman_table,
  file.path(output_dir, "MCF7_Friedman_overall.csv"),
  row.names = FALSE
)

write.csv(
  wilcoxon_results,
  file.path(output_dir, "MCF7_paired_Wilcoxon_vs_control.csv"),
  row.names = FALSE
)

capture.output(
  cat("MCF-7 Friedman test\n"),
  print(friedman_mcf7),
  cat("\nKendall's W =", kendall_w, "\n"),
  cat("\nPaired Wilcoxon signed-rank tests\n"),
  print(wilcoxon_results, row.names = FALSE),
  file = file.path(
    output_dir,
    "MCF7_Friedman_Wilcoxon_results.txt"
  )
)
