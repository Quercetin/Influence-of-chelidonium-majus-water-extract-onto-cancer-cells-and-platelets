# ================================================================
# Run all Friedman and Wilcoxon analyses
# Results are written directly into the current working directory.
# ================================================================

scripts <- c(
  "01_MCF7_Friedman_Wilcoxon.R",
  "02_Lymphocytes_Friedman_Wilcoxon.R",
  "03_MCF7_vs_Lymphocytes_Wilcoxon.R"
)

missing <- scripts[!file.exists(scripts)]

if (length(missing) > 0L) {
  stop(
    "Missing script files: ",
    paste(missing, collapse = ", "),
    "\nCurrent working directory: ",
    getwd()
  )
}

test_file <- file.path(
  getwd(),
  paste0("write_test_", Sys.getpid(), ".tmp")
)

if (!isTRUE(suppressWarnings(file.create(test_file)))) {
  stop(
    "R cannot write to the current working directory: ",
    getwd()
  )
}

unlink(test_file)

cat(
  "Working and output directory: ",
  normalizePath(getwd(), winslash = "/", mustWork = TRUE),
  "\n",
  sep = ""
)

status <- setNames(rep("not started", length(scripts)), scripts)

for (script in scripts) {
  cat("\n\nRUNNING: ", script, "\n", sep = "")

  result <- tryCatch(
    {
      source(script, echo = FALSE, local = globalenv())
      "completed"
    },
    error = function(e) {
      message(
        "ERROR IN ",
        script,
        ": ",
        conditionMessage(e)
      )
      paste0("failed: ", conditionMessage(e))
    }
  )

  status[[script]] <- result
}

cat("\n================ FINAL STATUS ================\n")
print(status)

if (isTRUE(all(status == "completed"))) {
  cat("\nAll analyses completed successfully.\n")
} else {
  cat("\nAt least one script failed.\n")
}
