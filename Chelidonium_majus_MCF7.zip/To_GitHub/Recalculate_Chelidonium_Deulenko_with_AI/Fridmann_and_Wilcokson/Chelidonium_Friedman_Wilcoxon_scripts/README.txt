FRIEDMAN AND WILCOXON ANALYSIS
Chelidonium majus MTT data

Experimental design
-------------------
- Four independent experiments.
- All doses and the untreated control were measured within each experiment.
- Therefore, dose-versus-control comparisons are paired.
- MCF-7 and lymphocyte experiment series are unpaired between cell types.

Primary non-parametric analyses
-------------------------------
1. Friedman test:
   tests the overall effect of dose within each cell type while preserving
   the repeated-measures structure across experiments.

2. Paired Wilcoxon signed-rank tests:
   compare each dose with the corresponding untreated control within the same
   experiment.

3. Unpaired Wilcoxon rank-sum tests:
   compare normalised MCF-7 and lymphocyte responses at each shared dose.

Multiplicity
------------
Holm correction is applied across the family of dose-specific Wilcoxon tests.
Raw p-values are also reported.

Important limitation
--------------------
With n = 4 experiments, exact paired Wilcoxon p-values are very coarse.
For four non-zero paired differences all pointing in the same direction,
the smallest two-sided exact p-value is 0.125. Therefore, dose-specific
paired Wilcoxon tests cannot reach p < 0.05 at n = 4, even under perfect
directional consistency. The Friedman test can still detect an overall
dose effect because it uses all dose levels simultaneously.

Files
-----
01_MCF7_Friedman_Wilcoxon.R
02_Lymphocytes_Friedman_Wilcoxon.R
03_MCF7_vs_Lymphocytes_Wilcoxon.R
04_run_all.R
05_STATISTICAL_GUIDANCE.txt
