# ================================================================
# Non-parametric analysis: Friedman + Wilcoxon
# Results are saved directly in the current working directory.
# ================================================================

get_output_dir <- function() {
  out <- getwd()

  if (!dir.exists(out)) {
    stop("Working directory does not exist: ", out)
  }

  test_file <- file.path(
    out,
    paste0("write_test_", Sys.getpid(), ".tmp")
  )

  created <- suppressWarnings(file.create(test_file))

  if (!isTRUE(created)) {
    stop(
      "R cannot write to the current working directory: ",
      out,
      "\nMove the scripts to a writable folder, for example C:/Rwork/..."
    )
  }

  unlink(test_file)
  normalizePath(out, winslash = "/", mustWork = TRUE)
}

output_dir <- get_output_dir()
cat("Output directory: ", output_dir, "\n", sep = "")

paired_wilcoxon_safe <- function(x, y) {
  # Exact test is attempted first. If ties or zero differences prevent
  # exact inference, R automatically falls back to the normal approximation.
  warning_message <- NULL

  result <- withCallingHandlers(
    tryCatch(
      stats::wilcox.test(
        x = x,
        y = y,
        paired = TRUE,
        alternative = "two.sided",
        exact = TRUE,
        correct = FALSE,
        conf.int = FALSE
      ),
      error = function(e) NULL
    ),
    warning = function(w) {
      warning_message <<- conditionMessage(w)
      invokeRestart("muffleWarning")
    }
  )

  if (is.null(result) || !is.null(warning_message)) {
    result <- stats::wilcox.test(
      x = x,
      y = y,
      paired = TRUE,
      alternative = "two.sided",
      exact = FALSE,
      correct = FALSE,
      conf.int = FALSE
    )
    exact_used <- FALSE
  } else {
    exact_used <- TRUE
  }

  list(test = result, exact_used = exact_used)
}

rank_biserial_paired <- function(differences) {
  differences <- differences[differences != 0]

  if (length(differences) == 0L) {
    return(0)
  }

  ranks <- rank(abs(differences), ties.method = "average")
  w_plus <- sum(ranks[differences > 0])
  w_minus <- sum(ranks[differences < 0])

  (w_plus - w_minus) / (w_plus + w_minus)
}

mcf7_wide <- data.frame(
  experiment = factor(1:4),
  check.names = FALSE,
  "3"          = c(0.423, 0.501, 0.512, 0.363),
  "1.5"        = c(0.396, 0.525, 0.468, 0.416),
  "0.75"       = c(0.632, 1.085, 0.875, 0.407),
  "0.375"      = c(0.666, 0.604, 0.671, 0.428),
  "0.1875"     = c(0.762, 1.167, 0.755, 1.013),
  "0.09375"    = c(0.983, 1.021, 0.835, 0.790),
  "0.046875"   = c(1.196, 1.292, 1.206, 1.173),
  "0.0234375"  = c(1.170, 1.110, 0.679, 0.392),
  "0.01171875" = c(1.187, 1.111, 1.205, 0.730),
  "0"          = c(1.304, 0.871, 1.207, 0.798)
)

lymph_wide <- data.frame(
  experiment = factor(1:4),
  check.names = FALSE,
  "3"          = c(0.136, 0.125, 0.170, 0.156),
  "1.5"        = c(0.388, 0.385, 0.375, 0.341),
  "0.75"       = c(0.388, 0.441, 0.415, 0.397),
  "0.375"      = c(0.423, 0.488, 0.4337, 0.398),
  "0.1875"     = c(0.499, 0.482, 0.470, 0.387),
  "0.09375"    = c(0.397, 0.429, 0.386, 0.411),
  "0.046875"   = c(0.403, 0.401, 0.408, 0.4712),
  "0.0234375"  = c(0.449, 0.454, 0.414, 0.489),
  "0.01171875" = c(0.431, 0.496, 0.437, 0.456),
  "0"          = c(0.429, 0.453, 0.479, 0.3987)
)

common_doses <- intersect(
  setdiff(names(mcf7_wide), c("experiment", "0")),
  setdiff(names(lymph_wide), c("experiment", "0"))
)

mcf7_control <- mcf7_wide[["0"]]
lymph_control <- lymph_wide[["0"]]

rank_biserial_unpaired <- function(U, n1, n2) {
  (2 * U) / (n1 * n2) - 1
}

results <- do.call(
  rbind,
  lapply(
    common_doses,
    function(dose_name) {
      # Normalise each experiment to its own control.
      mcf7_lrr <- log(
        mcf7_wide[[dose_name]] / mcf7_control
      )
      lymph_lrr <- log(
        lymph_wide[[dose_name]] / lymph_control
      )

      wt <- stats::wilcox.test(
        x = mcf7_lrr,
        y = lymph_lrr,
        paired = FALSE,
        alternative = "two.sided",
        exact = TRUE,
        correct = FALSE,
        conf.int = FALSE
      )

      U <- unname(wt$statistic)
      n1 <- length(mcf7_lrr)
      n2 <- length(lymph_lrr)

      data.frame(
        dose = dose_name,
        n_MCF7 = n1,
        n_lymphocytes = n2,
        median_log_ratio_MCF7 = median(mcf7_lrr),
        median_log_ratio_lymphocytes = median(lymph_lrr),
        median_viability_MCF7 =
          100 * median(exp(mcf7_lrr)),
        median_viability_lymphocytes =
          100 * median(exp(lymph_lrr)),
        U = U,
        rank_biserial_unpaired =
          rank_biserial_unpaired(U, n1, n2),
        p_raw = wt$p.value,
        stringsAsFactors = FALSE
      )
    }
  )
)

results$p_holm <- p.adjust(results$p_raw, method = "holm")
results$significant_raw_0_05 <- results$p_raw < 0.05
results$significant_holm_0_05 <- results$p_holm < 0.05

cat(
  "\n=== MCF-7 VS LYMPHOCYTES: UNPAIRED WILCOXON ===\n"
)
print(results, row.names = FALSE)

cat(
  "\nNOTE: These are dose-specific between-cell comparisons.\n",
  "They do not constitute an omnibus cell-by-dose interaction test.\n",
  sep = ""
)

write.csv(
  results,
  file.path(
    output_dir,
    "MCF7_vs_Lymphocytes_unpaired_Wilcoxon.csv"
  ),
  row.names = FALSE
)

capture.output(
  cat(
    "MCF-7 versus lymphocyte unpaired Wilcoxon rank-sum tests\n\n"
  ),
  print(results, row.names = FALSE),
  cat(
    "\nTests compare within-experiment log response ratios at each dose.\n",
    "No omnibus interaction is estimated by this script.\n"
  ),
  file = file.path(
    output_dir,
    "MCF7_vs_Lymphocytes_Wilcoxon_results.txt"
  )
)
